<script setup lang="ts">
if (typeof window !== 'undefined') {

}
</script>

<template>
  <canvas id="page-background-home"></canvas>
</template>


<style lang="sass">
  canvas
    width: 100%
    height: 100%
    position: fixed
    top: 0
    left: 0
    z-index: 1
    border: none
    background: #ddd
</style>

