import { atom } from 'nanostores'
/**
 * @property {boolean} menuOpen
 */
export const menuOpen = atom(false)