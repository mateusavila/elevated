declare module 'three/addons/geometries/TextGeometry.js'
declare module 'three/addons/loaders/FontLoader.js'
declare module '@vuelidate/components'
declare module 'googleapis'